const { YakuziABI } = require('./addresses/YakuziNFTABI.js');
const { web3, web3Provider, web3ETHProvider } = require('./utils/admin');
const contractaddress = "0x454cBC099079DC38b145E37e982e524AF3279c44";

//const { ABI } = require('./addresses/YakuziNFTABI.js');

let counter = 0;  //counter to keep track of number of times the setInterval Cb is called
let dataInterval; // to s
const main = async () => {


    var minusZahl = -0.5;
var plusZahl = 0.5;

var sum = minusZahl + plusZahl;
console.log(sum);

    
    //const nftContract = new web3ETHProvider.eth.Contract(YakuziABI, contractaddress);
        
    //const addresses = await web3ETHProvider.eth.getAccounts();
    
//console.log(addresses[0]);

    const print_data = async () => {
        console.log("Hello")
        counter++;
        const data = await nftContract.methods.getSalePrice().call();
        //secondAsync();
        //console.log(returnHello);
        console.log(data);
        console.log(counter);
        if (counter >= '30') {
            console.log("asd");
            clearInterval(dataInterval);
        }
    }

    const print_data11 = async () => {
        console.log("Hello1111")
        //counter++;
        const data = await nftContract.methods.getSalePrice().call();
        //secondAsync();
        //console.log(returnHello);
        console.log(data);
        console.log(counter);
        if (counter >= '30') {
            console.log("asd");
            clearInterval(dataInterval);
        }
    }
    
    
    async function main1() {
        process.stderr.write("--Start--")
        dataInterval = setInterval(print_data, 5000); //60 seconds
        dataInterval2 = setInterval(print_data11, 1000);
    }
/*
    const secondAsync = async () => {
        console.log("Hello2time")
        
        const data = await nftContract.methods.getSalePrice().call();
        console.log(data);
        console.log(counter);
        if (counter >= '30') {
            console.log("asd");
            clearInterval(dataInterval);
        }
        return "halloReturn";
    }
    
*/
   

  
/*
    try {
        /*
        await traboContract.methods.swapsWETHForTokens("0xe9e7cea3dedca5984780bafc599bd69add087d56", routers.uniswapV2).send({
          from: addresses[0],
        });
        
        const data = await nftContract.methods.getSalePrice().call();
        console.log(data);
      } catch (error) {
        console.error(error);
      }
      */

      //main1();
};




main();