// node connection
const BigNumber = require('bignumber.js');
const { web3, web3ETH, web3Provider, web3ETHProvider} = require('./utils/admin');
const writeJson = require('./models/writeJson.js');
const { durchschnittsGasFeesMal2PlusPufferInDollar, mindestGewinnInDollarProBNB, swapAmountOhneWei, preisUnterschiedBeiWeiterenEinkäufenProBNB } = require('./helpers/swapAmount.js');
const buyAndSell = require('./models/BuyAndSell.js');

// configuration files
const { tokens, routers, ABIs, factories } = require('./addresses/ethereum');
const { ABI, TraboABI } = require('./addresses/ArbitrageAbi.js');
const config = require('./config');

const traboContractAddress = "0x18Af1333e92948468e84b246A4068BdD36677f38";
const abitrageContractAddress = "0x401da40Da97f8F7F5739F7bA67d81e9FED776293";
// utils
const logger = require('./utils/logger');

// models
const EthereumCalculator = require('./models/EthereumCalculator');
const DexPriceAddress = require('./models/DexPriceAddress');

const PreisAndSteigung = require('./models/PreisAndSteigung');
const { Console } = require('winston/lib/winston/transports');
const { write } = require('./utils/logger');




const main = async () => {
  console.log(durchschnittsGasFeesMal2PlusPufferInDollar);
  
  // user input of 2 tokens

  const swapFrom = 'WETH'; // Enter token name (3-4 letters)
  const swapTo = 'DAI';

  const swapAmount = BigNumber((swapAmountOhneWei) * 1e+18); // in wei

  var einkaufsPreiseProBNB = [];
  await writeJson.readBuys("activBuys")
  .then((res) => einkaufsPreiseProBNB = res.table)
  .catch((err) => console.log(err));

  console.log(einkaufsPreiseProBNB);
  
  const traboContract = new web3.eth.Contract(TraboABI, traboContractAddress)
  
  const addresses = await web3Provider.eth.getAccounts();
  console.log(addresses[0]);

  /*
  var contract = new web3.eth.Contract(ABI.abi, abitrageContractAddress);
  console.log("hi");
  const data = await traboContract.methods.returnCurrentBalanceOf(tokens.WETH).call();
  console.log(data);
*/

     /* !!!!!!!!1111******************* IDEEEE ********* !!!!!!!!!1
   Bei einkaufen checken das der einkauf davor teurer war^^
   Wenn ein eingekauft dann nur nochmal einkaufen wenn preis billiger ist, weil sonst zu oft eingekauft wird
Faktor einbauen dass wenn mehr verkäufe sind der preis unterschied in Prozent billiger sein muss  (evtl anzahl an Verkäufe in prozent oda pro einkauf halber prozent start 0 = halber prozent billiger)
   
  Immer nur ein packet verkaufen! außer wenn über bestimmten anzahl viele einkäufe sind dann soll er 2-3 auf einmal verkaufen (die halt profite machen)
  und ab bestimmter zahl soll er so viele verkaufen wie möglich sind!!


   Array mit allen durchschnitts steigungen speichert und davon den mittelwert, gibt an ob grad preis auf oder abstieg war bzw ist

   Wenn Mittelwert Steigung Positiv und ein(oder 2) index Davor größer ist als Letzter -> Überprüfen ob verkauf möglich
   */

  //console.log(addresses[0]);

  /*
  try {
  
        // function swap(address _tokenIn, address _tokenOut, uint256 _amountIn, uint256 _amountOutMin, address _to, address _router) external onlyOwner{
    await traboContract.methods.swap(tokens.WETH, tokens.DAI, 1000, 0, traboContractAddress, routers.uniswapV2).send({
    //await traboContract.methods.payOutAllFunds(tokens.DAI).send({
      //await traboContract.methods.includeCanPayOut("0x7c577d53d9C1EC3AcD0416e5FB76482c50d5e29b", true).send({
        from: addresses[0],
      });
  }
  catch (e) {
    // Anweisungen für jeden Fehler
    console.log(e); // Fehler-Objekt an die Error-Funktion geben
 }
 */
  

  
  //const data1 = await traboContract.methods.returnCurrentBalanceOf(tokens.DAI).call();
  //console.log(data1);

  /*
  await contract.methods.includeCanPayOut(addresses[0], true).send({
    from: addresses[0],
  });
*/
  /* This creates and event emitter linked to eth_subscribe */
  const subscription = web3.eth.subscribe('newBlockHeaders');

  
 

  var last10BuyPreisArray = [];
  var last10SellPreisArray = [];

  var last100MittelWerteSteigungBuy = [];
  var last100MittelWerteSteigungSell = [];
  /* This exposes the events from the subscription, synchronously */

  subscription.on('data', async (block, error) => {
    console.log("length of EinkaufspreisproBNB Array = " + einkaufsPreiseProBNB.length);
    
    logger.debug('============================================');
    // current block number
    logger.debug(`New block: ${block.number}`);

    // average gas price
    const gasPrice = await web3.eth.getGasPrice();
    logger.debug(`Gas price: ${Math.floor(web3.utils.fromWei(gasPrice, 'gwei'))}`);

    //Date
    let date_ob = new Date();
    let date = ("0" + date_ob.getDate()).slice(-2);
    let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
    let year = date_ob.getFullYear();
    // current hours
    let hours = date_ob.getHours();
     // current minutes
   let minutes = date_ob.getMinutes();
    // current seconds
    let seconds = date_ob.getSeconds();

    let currentDate = year + "-" + month + "-" + date + ":" + hours + ":" + minutes + ":" + seconds;

    
    // initialise uniswap v2 calculator
    const uniswapV2EthCalc = new EthereumCalculator(ABIs.uniswapV2Router, routers.uniswapV2, tokens[swapFrom], tokens[swapTo], swapAmount);
    const uniswapV2SellPrice = await uniswapV2EthCalc.getSellPrice();
    const uniswapV2V2BuyPrice = await uniswapV2EthCalc.getBuyPrice();
    const uniswapV2BuyPriceClass = new DexPriceAddress(uniswapV2EthCalc.routerAddress, factories.uniswapV2, uniswapV2V2BuyPrice/swapAmountOhneWei, "pancake");
    const uniswapV2SellPriceClass = new DexPriceAddress(uniswapV2EthCalc.routerAddress, factories.uniswapV2, uniswapV2SellPrice/swapAmountOhneWei, "pancake");

    // initialise sushiswap v2 calculator
    const sushiswapV2EthCalc = new EthereumCalculator(ABIs.sushiswapV2Router, routers.sushiswapV2, tokens[swapFrom], tokens[swapTo], swapAmount);
    const sushiswapV2SellPrice = await sushiswapV2EthCalc.getSellPrice();
    const sushiswapV2BuyPrice = await sushiswapV2EthCalc.getBuyPrice();
    const sushiswapV2BuyPriceClass = new DexPriceAddress(sushiswapV2EthCalc.routerAddress, factories.sushiswapV2, sushiswapV2BuyPrice/swapAmountOhneWei, "biswap");
    const sushiswapV2SellPriceClass = new DexPriceAddress(sushiswapV2EthCalc.routerAddress, factories.sushiswapV2, sushiswapV2SellPrice/swapAmountOhneWei, "biswap");

    // initialise bakeryswap v2 calculator
    const bakeryswapV2EthCalc = new EthereumCalculator(ABIs.uniswapV2Router, routers.bakeryswap, tokens[swapFrom], tokens[swapTo], swapAmount);
    const bakerywapV2SellPrice = await bakeryswapV2EthCalc.getSellPrice();
    const bakeryswapV2BuyPrice = await bakeryswapV2EthCalc.getBuyPrice();
    const bakeryswapV2BuyPriceClass = new DexPriceAddress(bakeryswapV2EthCalc.routerAddress, factories.bakeryswap, bakeryswapV2BuyPrice/swapAmountOhneWei, "bakery");
    const bakeryswapV2SellPriceClass = new DexPriceAddress(bakeryswapV2EthCalc.routerAddress, factories.bakeryswap, bakerywapV2SellPrice/swapAmountOhneWei, "bakery");
    
    const apeswapV2EthCalc = new EthereumCalculator(ABIs.uniswapV2Router, routers.apeswap, tokens[swapFrom], tokens[swapTo], swapAmount);
    const apewapV2SellPrice = await apeswapV2EthCalc.getSellPrice();
    const apeswapV2BuyPrice = await apeswapV2EthCalc.getBuyPrice();
    const apewapV2BuyPriceClass = new DexPriceAddress(apeswapV2EthCalc.routerAddress, factories.apeswap, apeswapV2BuyPrice/swapAmountOhneWei, "apeswap");
    const apewapV2SellPriceClass = new DexPriceAddress(apeswapV2EthCalc.routerAddress, factories.apeswap, apewapV2SellPrice/swapAmountOhneWei, "apeswap");
   
    var BuyPriceClasses = [sushiswapV2BuyPriceClass, uniswapV2BuyPriceClass, apewapV2BuyPriceClass];
    var SellPriceClasses = [sushiswapV2SellPriceClass, uniswapV2SellPriceClass, apewapV2SellPriceClass, bakeryswapV2SellPriceClass];
    //0 Index von Buy ist billigste
    BuyPriceClasses = BuyPriceClasses.sort(function (a, b) {  return a.price - b.price;  });

    //0index von Sell ist teuerste
    SellPriceClasses = SellPriceClasses.sort(function (a, b) {  return b.price - a.price;  });
   
    
    logger.info(`${SellPriceClasses[0].name}   | 🟥 Sell | ${swapAmountOhneWei} ${swapFrom} rückgerechnet auf 1-> ${SellPriceClasses[0].price} ${swapTo}`);
    logger.info(`${BuyPriceClasses[0].name}   | 🟩 Buy  | ${swapAmountOhneWei} rückgerechnet auf 1-> ${BuyPriceClasses[0].price} ${swapTo}`);

    //logger.info(`UniswapV2   | 🟥 Sell | ${swapAmountOhneWei} ${swapFrom} -> ${uniswapV2SellPrice} ${swapTo}`);
    //logger.info(`UniswapV2   | 🟩 Buy  | ${swapAmountOhneWei} -> ${uniswapV2V2BuyPrice} ${swapTo}`);
    //logger.info(`SushiswapV2 | 🟥 Sell | ${swapAmountOhneWei} -> ${sushiswapV2SellPrice} ${swapTo}`);
    //logger.info(`SushiswapV2 | 🟩 Buy  | ${swapAmountOhneWei} -> ${sushiswapV2BuyPrice} ${swapTo}`);
    //logger.info(`BakerySwap | 🟥 Sell | ${swapAmountOhneWei} -> ${bakerywapV2SellPrice} ${swapTo}`);
    //logger.info(`BakerySwap | 🟩 Buy  | ${swapAmountOhneWei} -> ${bakeryswapV2BuyPrice} ${swapTo}`);
    //logger.info(`ApeSwap | 🟥 Sell | ${swapAmountOhneWei} -> ${apewapV2SellPrice} ${swapTo}`);
    //logger.info(`ApeSwap | 🟩 Buy  | ${swapAmountOhneWei} -> ${apeswapV2BuyPrice} ${swapTo}`);


    //letzten 10 Preise plus jeweilige Steigung speichern
  

  /*
    if (BuyPriceClasses[0].price < SellPriceClasses[0].price) {

      try {
        await contract.methods.startArbitrage(BuyPriceClasses[0].factoryAddress, BuyPriceClasses[0].routerAddress, tokens.WETH, tokens.DAI, swapAmount, 0).send({
          from: addresses[0],
        });
      } catch (error) {
        console.error(error);
      }

      const jsonnameFlash = "flashloan.json";
      writeJson.writeJson(jsonnameFlash, block, swapAmountOhneWei, uniswapV2V2BuyPrice, sushiswapV2BuyPrice, bakeryswapV2BuyPrice, apeswapV2BuyPrice, sushiswapV2SellPrice, uniswapV2SellPrice, bakerywapV2SellPrice, apewapV2SellPrice);
      // Hier Contract start Flashloan Function aufrufen
    }*/

    if (last10BuyPreisArray.length >= 80) {
      einkaufsPreiseProBNB.length
      console.log("länge einkaufspreisepro BNBnp" + einkaufsPreiseProBNB.length)
      console.log("mehr als 100in Array");
      
      const kbuy = PreisAndSteigung.calculateSteigung(last10BuyPreisArray[last10BuyPreisArray.length - 1].block.timestamp, block.timestamp, last10BuyPreisArray[last10BuyPreisArray.length - 1].price, BuyPriceClasses[0].price);
      const preisAndSteigungBuy = new PreisAndSteigung.PreisAndSteigung(BuyPriceClasses[0].price, kbuy, block);
      //console.log("buy");
      //console.log(kbuy);
      last10BuyPreisArray.shift();
      last10BuyPreisArray.push(preisAndSteigungBuy);

      const ksell = PreisAndSteigung.calculateSteigung(last10SellPreisArray[last10SellPreisArray.length - 1].block.timestamp, block.timestamp, last10SellPreisArray[last10SellPreisArray.length - 1].price, SellPriceClasses[0].price);
      const preisAndSteigungSell = new PreisAndSteigung.PreisAndSteigung(SellPriceClasses[0].price, ksell, block);
      //console.log("sell");
      //console.log(ksell);
      last10SellPreisArray.shift();
      last10SellPreisArray.push(preisAndSteigungSell);

      const mittelWertLast100SteigungBuy = PreisAndSteigung.calculateSteigung(last10BuyPreisArray[0].block.timestamp, block.timestamp, last10BuyPreisArray[0].price, BuyPriceClasses[0].price);
      const mittelWertLast100SteigungSell = PreisAndSteigung.calculateSteigung(last10SellPreisArray[0].block.timestamp, block.timestamp, last10SellPreisArray[0].price, SellPriceClasses[0].price);
      last100MittelWerteSteigungBuy.shift();
      last100MittelWerteSteigungBuy.push(mittelWertLast100SteigungBuy);
      last100MittelWerteSteigungSell.shift();
      last100MittelWerteSteigungSell.push(mittelWertLast100SteigungSell);
      const wertMittelKBuy = PreisAndSteigung.calculateMittelWertSteigung(last100MittelWerteSteigungBuy);
      const wertMittelKSell = PreisAndSteigung.calculateMittelWertSteigung(last100MittelWerteSteigungSell);
      console.log("last 100kBuy mittelwert buy sell");
      console.log(wertMittelKBuy);
      console.log(wertMittelKSell);
      //last 100 k buy
      console.log("last100kbuy 2 sell");
      console.log(mittelWertLast100SteigungBuy);
      console.log(mittelWertLast100SteigungSell);

      var sellpricemittolleranz = SellPriceClasses[0].price - (durchschnittsGasFeesMal2PlusPufferInDollar + mindestGewinnInDollarProBNB);
      console.log("SellPrice mit Toleranzt = " + sellpricemittolleranz);


      var buyPricemitToleranz = BuyPriceClasses[0].price + preisUnterschiedBeiWeiterenEinkäufenProBNB;
      console.log("buyPricemitToleranz  = " + buyPricemitToleranz);

      //console.log("letze einkauspreispro bnb = " + einkaufsPreiseProBNB[einkaufsPreiseProBNB.length - 1].price);
      //Wenn mittelwertLast100SteigungBuy/Sell 
      //Sell
      if (mittelWertLast100SteigungSell < 0 && wertMittelKSell > 0 && einkaufsPreiseProBNB.length > 0) {

       var counter = einkaufsPreiseProBNB.length - 1;
       var mindAmountOut = 0;
       var maxEinkäufe = 1;
        
        if (einkaufsPreiseProBNB.length > 7) {
          maxEinkäufe = einkaufsPreiseProBNB.length;
        } else if  (einkaufsPreiseProBNB.length > 5) {
          maxEinkäufe = 5;
        } else if (einkaufsPreiseProBNB.length > 3) {
          maxEinkäufe = 3;
        } else {
          maxEinkäufe = 1;
        }
        var sellPriceAbzüglichToleranzen = SellPriceClasses[0].price - (durchschnittsGasFeesMal2PlusPufferInDollar + mindestGewinnInDollarProBNB);
        //Loop bedingung finden das i kleiner wird bis alle nötigen elemente im einkaufspreiseProBNB array überprüft werden.
        maxEinkäufe = einkaufsPreiseProBNB.length - maxEinkäufe;
        var anzVerkäufeCounter = 0;
        for (let i = counter; i >= maxEinkäufe; i--) {
          
          if (sellPriceAbzüglichToleranzen > einkaufsPreiseProBNB[i].price){
            anzVerkäufeCounter += 1;
             mindAmountOut += sellPriceAbzüglichToleranzen * swapAmountOhneWei;
          } else {
            break;
          }
        }
        if (mindAmountOut > 0) {
          //buyAndSell.Sell(mindAmountOut, SellPriceClasses[0].name, SellPriceClasses[0].price, SellPriceClasses[0].factoryAddress, SellPriceClasses[0].routerAddress, swapAmountOhneWei, currentDate, anzVerkäufeCounter);
          await buyAndSell.Sell(mindAmountOut, SellPriceClasses[0].name, SellPriceClasses[0].price, SellPriceClasses[0].factoryAddress, SellPriceClasses[0].routerAddress, swapAmountOhneWei, currentDate, anzVerkäufeCounter)
          .then((res) => einkaufsPreiseProBNB = res)
          .catch((err) => console.log(err));
          
          //nachher überprüfen ob verkauf tatsächlich durchgegangen ist und gegebenenfall in json schreiben

    }
       
        

      }
      //Buy
      if (mittelWertLast100SteigungBuy > 0 && wertMittelKBuy < 0) {
        
        if (einkaufsPreiseProBNB.length > 0) {
          //Wenn letzer kauf größer ist wie neuer Kaufpreis minus ToleranzWert
          var buyPriceZuzüglichToleranz = BuyPriceClasses[0].price + preisUnterschiedBeiWeiterenEinkäufenProBNB;
          if (buyPriceZuzüglichToleranz < einkaufsPreiseProBNB[einkaufsPreiseProBNB.length - 1].price) {
            //buyAndSell.Buy(mindAmountOut, SellPriceClasses[0].name, SellPriceClasses[0].price, SellPriceClasses[0].factoryAddress, SellPriceClasses[0].routerAddress, swapAmountOhneWei, currentDate);
            await buyAndSell.Buy(0, BuyPriceClasses[0].name, BuyPriceClasses[0].price, BuyPriceClasses[0].factoryAddress, BuyPriceClasses[0].routerAddress, swapAmountOhneWei, currentDate)
            .then((res) => einkaufsPreiseProBNB = res)
            .catch((err) => console.log(err));
          }
        } else {
          //buyAndSell.Buy(mindAmountOut, SellPriceClasses[0].name, SellPriceClasses[0].price, SellPriceClasses[0].factoryAddress, SellPriceClasses[0].routerAddress, swapAmountOhneWei, currentDate);
          await buyAndSell.Buy(0, BuyPriceClasses[0].name, BuyPriceClasses[0].price, BuyPriceClasses[0].factoryAddress, BuyPriceClasses[0].routerAddress, swapAmountOhneWei, currentDate)
            .then((res) => einkaufsPreiseProBNB = res)
            .catch((err) => console.log(err));
        }

      }
      

 

    } else if (last10BuyPreisArray.length < 1) {
      const preisAndSteigungSell = new PreisAndSteigung.PreisAndSteigung(SellPriceClasses[0].price, 0, block);
      const preisAndSteigungBuy = new PreisAndSteigung.PreisAndSteigung(BuyPriceClasses[0].price, 0, block);
     
      last10BuyPreisArray.push(preisAndSteigungBuy);
      last10SellPreisArray.push(preisAndSteigungSell);
    } else {
      const kbuy = PreisAndSteigung.calculateSteigung(last10BuyPreisArray[last10BuyPreisArray.length - 1].block.timestamp, block.timestamp, last10BuyPreisArray[last10BuyPreisArray.length - 1].price, BuyPriceClasses[0].price);
      const preisAndSteigungBuy = new PreisAndSteigung.PreisAndSteigung(BuyPriceClasses[0].price, kbuy, block);
      last10BuyPreisArray.push(preisAndSteigungBuy);

      const ksell = PreisAndSteigung.calculateSteigung(last10SellPreisArray[last10SellPreisArray.length - 1].block.timestamp, block.timestamp, last10SellPreisArray[last10SellPreisArray.length - 1].price, SellPriceClasses[0].price);
      const preisAndSteigungSell = new PreisAndSteigung.PreisAndSteigung(SellPriceClasses[0].price, ksell, block);
      last10SellPreisArray.push(preisAndSteigungSell);
      console.log("buy");
      console.log(kbuy);
      console.log("sell");
      console.log(ksell);

      const mittelWertLast100SteigungBuy = PreisAndSteigung.calculateSteigung(last10BuyPreisArray[0].block.timestamp, block.timestamp, last10BuyPreisArray[0].price, BuyPriceClasses[0].price);
      const mittelWertLast100SteigungSell = PreisAndSteigung.calculateSteigung(last10SellPreisArray[0].block.timestamp, block.timestamp, last10SellPreisArray[0].price, SellPriceClasses[0].price);
      last100MittelWerteSteigungBuy.push(mittelWertLast100SteigungBuy);
      last100MittelWerteSteigungSell.push(mittelWertLast100SteigungSell);
      const wertMittelKBuy = PreisAndSteigung.calculateMittelWertSteigung(last100MittelWerteSteigungBuy);
      const wertMittelKSell = PreisAndSteigung.calculateMittelWertSteigung(last100MittelWerteSteigungSell);
      console.log("last 100kBuy mittelwert buy sell");
      console.log(wertMittelKBuy);
      console.log(wertMittelKSell);
      //last 100 k buy
      console.log("last100kbuy 2 sell");
      console.log(mittelWertLast100SteigungBuy);
      console.log(mittelWertLast100SteigungSell);

      //überlegen wie man abfragt wan von minus auf plus geht, also merken dass jetz abwärtstrend vorbei ist

    }
      

    
    console.log(year + "-" + month + "-" + date + ":" + hours);

    var twentyMinutes = 0;
    var value = 10;
    twentyMinutes = minutes / value;

 
    var valueName = (twentyMinutes | 0)
    const jsonname = year + "-" + month + "-" + date + ":" + hours + ":" + valueName + ".json";
    const jsonnameOnlyHighLow = "HighLow" + year + "-" + month + "-" + date + ":" + hours + ":" + valueName + ".json";
    
    
    try {
     // writeJson.writeJson(jsonname, block, swapAmountOhneWei, uniswapV2V2BuyPrice, sushiswapV2BuyPrice, bakeryswapV2BuyPrice, apeswapV2BuyPrice, sushiswapV2SellPrice, uniswapV2SellPrice, bakerywapV2SellPrice, apewapV2SellPrice);
     // writeJson.writeJsonHighLow(jsonnameOnlyHighLow, block, swapAmountOhneWei, BuyPriceClasses[0].price, SellPriceClasses[0].price, BuyPriceClasses[0].name, SellPriceClasses[0].name);

    } catch (error) {
      console.error(error);
    }
  });

  
};

function oppositeSigns(x, y)
    {
        return ((x ^ y) < 0);
    }

  async function decideBuy() {

    
  }
  
  async function decideSell() {
    

  }





main();
