const { SnackAbi } = require('./addresses/snack.js');
const { web3, web3ETH, web3Provider, web3ETHProvider } = require('./utils/admin');
const contractaddress = "0xc051aAb77Edf25119b1A37740636DdBfb803C4e5";

const main = async () => {


    
    const nftContract = new web3ETH.eth.Contract(SnackAbi, contractaddress);
    const nftContractUser = new web3ETHProvider.eth.Contract(SnackAbi, contractaddress);
    const addresses = await web3ETHProvider.eth.getAccounts();
    
    console.log(addresses[0]);
    
    const data = await nftContract.methods.privateSaleIsActive().call();
    console.log(data);

    try {
                
        //From addresse in klammer 0 = 1. Wallet in metamask, 1 = 2. Wallet usw
        //Value Wert in eth eingeben
        //mintSeal(Zahl) = anzahl an Bildern die zu minten sind   
       await nftContractUser.methods.mintSeal(1).send({

           from: addresses[0],
           value: 1000000000000000000, 
          // gas: 100, //Gas Limit
           //gasPrice: ,
       });
   }
   catch (e) {
       // Anweisungen für jeden Fehler
       console.log(e); // Fehler-Objekt an die Error-Funktion geben
   }


    nftContract.events.Transfer({})
    .on('data', async function(event){
        console.log("log");
        console.log(event.returnValues[0]);
        if (event.returnValues[0] == "0x0000000000000000000000000000000000000000" && data == false) {
            console.log("huhu");
            try {
                
                //From addresse in klammer 0 = 1. Wallet in metamask, 1 = 2. Wallet usw
                //Value Wert in eth eingeben
                //mintSeal(Zahl) = anzahl an Bildern die zu minten sind   
               await nftContractUser.methods.mintSeal(1).send({
        
                   from: addresses[0],
                   value: 1000000000000000000, 
                  // gas: 100, //Gas Limit
                   //gasPrice: ,
               });
           }
           catch (e) {
               // Anweisungen für jeden Fehler
               console.log(e); // Fehler-Objekt an die Error-Funktion geben
           }
        }
        // Do something here
    })
    .on('error', console.error);



    
 
/*
    const print_data = async () => {
        console.log("Hello")
        counter++;
        const data = await nftContract.methods.getSalePrice().call();
        //secondAsync();
        //console.log(returnHello);
        console.log(data);
        console.log(counter);
        if (counter >= '30') {
            console.log("asd");
            clearInterval(dataInterval);
        }
    }

    const print_data11 = async () => {
        console.log("Hello1111")
        //counter++;
        const data = await nftContract.methods.getSalePrice().call();
        //secondAsync();
        //console.log(returnHello);
        console.log(data);
        console.log(counter);
        if (counter >= '30') {
            console.log("asd");
            clearInterval(dataInterval);
        }
    }
    
    
    async function main1() {
        process.stderr.write("--Start--")
        dataInterval = setInterval(print_data, 5000); //60 seconds
        dataInterval2 = setInterval(print_data11, 1000);
    }
    */


};




main();