// configuration files
const config = require('../config');
const key = require('../helpers/key.js');


const HDWalletProvider = require('@truffle/hdwallet-provider');
const CryptoJS = require("crypto-js");

const fs = require('fs');


// node api
const Web3 = require('web3');

// connecting to node
const web3 = new Web3(config.wssEndpoint);
const web3ETH = new Web3(config.eth_wssEndpoint);
//const web3Provider = new Web3(config.wssEndpoint);





var bytes  = CryptoJS.AES.decrypt(config.mnemonic , key);
var mnemonic= bytes.toString(CryptoJS.enc.Utf8);

//var mnemonic = config.mnemonic;

//BSC
let provider = new HDWalletProvider({
  mnemonic: mnemonic,
  providerOrUrl: config.wssEndpoint,
});
const web3Provider = new Web3(provider);
//web3Provider.setProvider(provider);

//ETH
let eth_provider = new HDWalletProvider({
  mnemonic: mnemonic,
  providerOrUrl: config.wssEndpoint,
});
const web3ETHProvider = new Web3(eth_provider);
//web3ETHProvider.setProvider(eth_provider);

module.exports = {
  web3,
  web3ETH,
  web3Provider,
  web3ETHProvider
}