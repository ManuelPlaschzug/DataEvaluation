//Sell
var einkaufsPreiseProBNBlength = 10
const buyAndSell = require('./models/BuyAndSell.js');
const writeJson = require('./models/writeJson.js');

const main = async () => {
  console.log("start");
  //die zwei funitonen bei kauf und verkauf in index einsegtzen
  /*
  await buyAndSell.Sell(1, "test", 1, "randomaddress", "randomaddress", 5, "Date", 1)
  .then((res) => console.log(res))
  .catch((err) => console.log(err));
  */
  /*
  await buyAndSell.Buy(1, "test", 0.001, "randomaddress", "randomaddress", 5, "Date")
  .then((res) => console.log(res))
  .catch((err) => console.log(err));


  */



  await writeJson.readBuys("activBuys")
  .then((res) => einkaufsPreiseProBNB = res.table)
  .catch((err) => console.log(err));

  console.log(einkaufsPreiseProBNB.length + " Länge einkaufspreiseprobnb");
  console.log(einkaufsPreiseProBNB);
  /*
        //Sell
        if (einkaufsPreiseProBNB.length > 0) {
          console.log("if");
          var counter = einkaufsPreiseProBNB.length - 1;
          var mindAmountOut = 0;
          var maxEinkäufe = 1;
          
          if (einkaufsPreiseProBNB.length > 7) {
            maxEinkäufe = einkaufsPreiseProBNB.length;
          } else if  (einkaufsPreiseProBNB.length > 5) {
            maxEinkäufe = 5;
          } else if (einkaufsPreiseProBNB.length > 3) {
            maxEinkäufe = 3;
          } else {
            maxEinkäufe = 1;
          }
          console.log("maxeinkäufe: " + maxEinkäufe);
          var sellPriceAbzüglichToleranzen = 4 - (1 + 1);
          //Loop bedingung finden das i kleiner wird bis alle nötigen elemente im einkaufspreiseProBNB array überprüft werden.
          console.log("sellPriceAbzüglichToleranzen: " + sellPriceAbzüglichToleranzen);
          maxEinkäufe = einkaufsPreiseProBNB.length - maxEinkäufe;
          console.log("maxeinkäufeneu: " + maxEinkäufe);
          var anzVerkäufeCounter = 0;
          for (let i = counter; i >= maxEinkäufe; i--) {
            console.log("i " + i);
            
            if (sellPriceAbzüglichToleranzen > einkaufsPreiseProBNB[i].price){
              anzVerkäufeCounter += 1;
              console.log("anzVerkäufeCounter " + anzVerkäufeCounter);
                mindAmountOut += sellPriceAbzüglichToleranzen * 5;
                console.log("mindamount: " + mindAmountOut);
            } else {
              console.log("break");
              break;
            }
          }
          if (mindAmountOut > 0) {
            console.log("mindamountout > 0  " + mindAmountOut);
            //buyAndSell.Sell(mindAmountOut, SellPriceClasses[0].name, SellPriceClasses[0].price, SellPriceClasses[0].factoryAddress, SellPriceClasses[0].routerAddress, swapAmountOhneWei, currentDate, anzVerkäufeCounter);
            await buyAndSell.Sell(1, "test", 1, "randomaddress", "randomaddress", 5, "Date", anzVerkäufeCounter)
            .then((res) => einkaufsPreiseProBNB = res)
            .catch((err) => console.log(err));

            console.log(einkaufsPreiseProBNB);
            
            //nachher überprüfen ob verkauf tatsächlich durchgegangen ist und gegebenenfall in json schreiben

        }
          
          

        }
        */
        //Buy
        
       
          
          if (einkaufsPreiseProBNB.length > 0) {
            console.log("einkaufspreiseprobnb lengt " + einkaufsPreiseProBNB.length)
            //Wenn letzer kauf größer ist wie neuer Kaufpreis minus ToleranzWert
            var buyPriceZuzüglichToleranz = 0.00001;
            if (buyPriceZuzüglichToleranz < einkaufsPreiseProBNB[einkaufsPreiseProBNB.length - 1].price) {
              console.log("kleiner als einkauf davor");
              //buyAndSell.Buy(mindAmountOut, SellPriceClasses[0].name, SellPriceClasses[0].price, SellPriceClasses[0].factoryAddress, SellPriceClasses[0].routerAddress, swapAmountOhneWei, currentDate);
              await buyAndSell.Buy(1, "test", 1, "randomaddress", "randomaddress", 5, "Date")
              .then((res) => einkaufsPreiseProBNB = res)
              .catch((err) => console.log(err));
            }
          } else {
            console.log("keineinkauf davor");
            //buyAndSell.Buy(mindAmountOut, SellPriceClasses[0].name, SellPriceClasses[0].price, SellPriceClasses[0].factoryAddress, SellPriceClasses[0].routerAddress, swapAmountOhneWei, currentDate);
            await buyAndSell.Buy(1, "test", 1, "randomaddress", "randomaddress", 5, "Date")
              .then((res) => einkaufsPreiseProBNB = res)
              .catch((err) => console.log(err));
          }
          console.log(einkaufsPreiseProBNB);

        
        




  /*
  var einkaufsPreiseProBNB = [];
  await writeJson.readBuys("activBuys")
  .then((res) => einkaufsPreiseProBNB = res.table)
  .catch((err) => console.log(err));

  console.log(einkaufsPreiseProBNB);
  console.log("ende");

  */
  
  //buyAndSell.Sell(1, "test", 1, "randomaddress", "randomaddress", 5, "Date", 2);
  //buyAndSell.Sell(mindAmountOut, SellPriceClasses[0].name, SellPriceClasses[0].price, SellPriceClasses[0].factoryAddress, SellPriceClasses[0].routerAddress, swapAmountOhneWei, currentDate, anzVerkäufeCounter);
            
  /*
      var counter = einkaufsPreiseProBNBlength - 1;
      var mindAmountOut = 0;
      var maxEinkäufe = 5;



      //Loop bedingung finden das i kleiner wird bis alle nötigen elemente im einkaufspreiseProBNB array überprüft werden.
      maxEinkäufe = einkaufsPreiseProBNBlength - maxEinkäufe;
      for (let i = counter; i >= maxEinkäufe; i--) {
          console.log("i:");
        console.log(i);
        
      }
      if (mindAmountOut > 0) {
          console.log("kauf oder verkauf");
      }
      */
    
    };
    main();