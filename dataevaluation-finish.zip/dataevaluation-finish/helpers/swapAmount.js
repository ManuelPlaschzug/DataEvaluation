const swapAmountOhneWei = 5;
const durchschnittsGasFeesMal2PlusPufferInDollar = 1;
const mindestGewinnInDollarProBNB = 2;
const preisUnterschiedBeiWeiterenEinkäufenProBNB = 3;

module.exports = {
    durchschnittsGasFeesMal2PlusPufferInDollar,
    mindestGewinnInDollarProBNB,
    swapAmountOhneWei,
    preisUnterschiedBeiWeiterenEinkäufenProBNB,
};