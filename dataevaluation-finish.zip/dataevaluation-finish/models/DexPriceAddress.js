// swapAmriceAdressount: wei
class DexPriceAddress {
  constructor(routerAddress, factoryAddress, price, name) {
    this.name = name;
    this.price = price;
    this.factoryAddress = factoryAddress;
    this.routerAddress = routerAddress;
  }

}

module.exports = DexPriceAddress;
