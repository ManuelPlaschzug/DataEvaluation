const fs = require('fs');

// get ABI of an verified contract

function read (jsonname) {
  const path = jsonname;

  return new Promise((resolve, reject) => {
    if (fs.existsSync(path)) {
      // path exists
      console.log("exists:", path);
      fs.readFile(path, 'utf8', function (err, data){
        if (err){
            console.log(err);
            reject("");
        } else {
        obj = JSON.parse(data); //now it an object
        //console.log(obj);
        resolve(obj);
      }});
  
    } else {
  
     console.log("No such File :" + jsonname);
     reject("");
  
    }
  });

  

}





module.exports = {
  read,

};
