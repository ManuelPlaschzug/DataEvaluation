const { web3, web3ETH, web3Provider, web3ETHProvider, } = require('../utils/admin');
const writeJson = require('../models/writeJson.js');
const swapAmountOhneWei = require('../helpers/swapAmount.js');

// get ABI of an verified contract

const Buy = async (mindAmountOut, name, price, factoryAdress, routerAddress, swapAmount, currentDate) => {
    var jsonname = "Buy";
    return new Promise(async(resolve, reject) => { 
      try  {
          console.log("1");
            
          await writeJson.writeJsonBuySell(jsonname, mindAmountOut, name, price, factoryAdress, routerAddress, swapAmount, currentDate)
          .then((res) => console.log("writejsonbuysell"))
          .catch((err) => reject((err)));
          await writeJson.writeJsonBuySell("activBuys", mindAmountOut, name, price, factoryAdress, routerAddress, swapAmount, currentDate)
          .then((res) => resolve(res))
          .catch((err) => reject((err)));
          // writeJson.writeJsonHighLow(jsonnameOnlyHighLow, block, swapAmountOhneWei, BuyPriceClasses[0].price, SellPriceClasses[0].price, BuyPriceClasses[0].name, SellPriceClasses[0].name);
          
        } catch (error) {
          console.error(error);
          reject(error);
        }


      });

  
};


const Sell = async (mindAmountOut, name, price, factoryAdress, routerAddress, swapAmount, currentDate, anzVerkäufeCounter) => {
    var jsonname = "Sell";
   return new Promise(async(resolve, reject) => { 
    try {
 
       await writeJson.writeJsonBuySell(jsonname, mindAmountOut, name, price, factoryAdress, routerAddress, swapAmount, currentDate)
       .then((res) => console.log("writejsonbuysell"))
        .catch((err) => reject((err)));
       await writeJson.overwriteAktivBuys("activBuys", anzVerkäufeCounter)
        .then((res) => resolve(res))
        .catch((err) => reject((err)));

       // writeJson.writeJsonHighLow(jsonnameOnlyHighLow, block, swapAmountOhneWei, BuyPriceClasses[0].price, SellPriceClasses[0].price, BuyPriceClasses[0].name, SellPriceClasses[0].name);
      // überprüfen ob verkauf tatsächlich funktioniert hat dann wirite json ausführen das gleiche beimkaufen
      //hier letzten anzVerkäufeCounter aus active buys löschen
      } catch (error) {
        console.error(error);
        reject(error);
      }


    });




  
};





module.exports = {
  Buy,
  Sell,
};
