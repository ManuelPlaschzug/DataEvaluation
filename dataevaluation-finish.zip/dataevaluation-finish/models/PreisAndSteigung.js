// swapAmriceAdressount: wei
class PreisAndSteigung {
    constructor(price, steigung, block) {
      this.price = price;
      this.steigung = steigung;
      this.block = block;
    }
  
  }

  const calculateSteigung = function (x1, x2, y1, y2) {
    const deltax = x2 - x1;
    const deltay = y2 - y1;
    const k = deltay/deltax;
    return k;
  }

  //einfach steigung zwischen ersten und letzten punkt ausrechen = mittelwert LOL funktion ist für nichts
const calculateMittelWertSteigung = function (array) {
    var sum = 0;
    for (let i in array) {
       sum += array[i];
     }
     var mittelwert = sum / array.length;
     return mittelwert;
}
  
  module.exports = {
      PreisAndSteigung,
      calculateSteigung, 
      calculateMittelWertSteigung,
  }
  