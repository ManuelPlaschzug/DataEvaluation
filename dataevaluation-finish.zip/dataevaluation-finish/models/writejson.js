const fs = require('fs');
const { swapAmountOhneWei } = require('../helpers/swapAmount');

// get ABI of an verified contract

const writeJson = async (jsonname, block, swapAmountOhneWei, uniswapV2V2BuyPrice, sushiswapV2BuyPrice, bakeryswapV2BuyPrice, apeswapV2BuyPrice, sushiswapV2SellPrice,  uniswapV2SellPrice,  bakerywapV2SellPrice, apeswapV2SellPrice) => {
  const path = jsonname;

  if (fs.existsSync(path)) {
    // path exists
    console.log("exists:", path);
    fs.readFile(path, 'utf8', function (err, data){
      if (err){
          console.log(err);
      } else {
      obj = JSON.parse(data); //now it an object
      obj.table.push({block: block.number, timestamp: block.timestamp, swapAmountBNB: swapAmountOhneWei, uniswapv2buyprice: uniswapV2V2BuyPrice, sushiswapv2buyprice: sushiswapV2BuyPrice, bakeryswapbuyprice: bakeryswapV2BuyPrice, apeswapBuyPrice: apeswapV2BuyPrice, uniswapv2sellprice: uniswapV2SellPrice, sushiswapv2sellprice: sushiswapV2SellPrice, bakeryswapsellprice: bakerywapV2SellPrice, apeswapsellprice: apeswapV2SellPrice});
      json = JSON.stringify(obj); //convert it back to json
      fs.writeFile(path, json, 'utf8', function (err) {
        if (err) {
            console.log("An error occured while writing JSON Object to File.");
            return console.log(err);
        }
      
        console.log("JSON file has been saved.");
      });
    }});

  } else {

    var obj = {
      table: []
   };

   obj.table.push({block: block.number, timestamp: block.timestamp, swapAmountBNB: swapAmountOhneWei, uniswapv2buyprice: uniswapV2V2BuyPrice, sushiswapv2buyprice: sushiswapV2BuyPrice, bakeryswapbuyprice: bakeryswapV2BuyPrice, apeswapBuyPrice: apeswapV2BuyPrice, uniswapv2sellprice: uniswapV2SellPrice, sushiswapv2sellprice: sushiswapV2SellPrice, bakeryswapsellprice: bakerywapV2SellPrice, apeswapsellprice: apeswapV2SellPrice});
   var json = JSON.stringify(obj);
  
   fs.writeFile(path, json, 'utf8', function (err) {
    if (err) {
        console.log("An error occured while writing JSON Object to File.");
        return console.log(err);
    }
  
    console.log("JSON file has been saved.");
  });
    console.log("DOES NOT exist:", path);

  }






  
};


const writeJsonHighLow = async (jsonname, block, swapAmountOhneWei, buyPrice, sellPrice, namebuy, namesell) => {
  const path = jsonname;

  if (fs.existsSync(path)) {
    // path exists
    console.log("exists:", path);
    fs.readFile(path, 'utf8', function (err, data){
      if (err){
          console.log(err);
      } else {
      obj = JSON.parse(data); //now it an object
      obj.table.push({block: block.number, timestamp: block.timestamp, swapAmountBNB: swapAmountOhneWei, namebuy: namebuy, buyPrice: buyPrice, namesell: namesell, sellPrice: sellPrice,});
      json = JSON.stringify(obj); //convert it back to json
      fs.writeFile(path, json, 'utf8', function (err) {
        if (err) {
            console.log("An error occured while writing JSON Object to File.");
            return console.log(err);
        }
      
        console.log("JSON file has been saved.");
      });
    }});

  } else {

    var obj = {
      table: []
   };

   obj.table.push({block: block.number, timestamp: block.timestamp, swapAmountBNB: swapAmountOhneWei, namebuy: namebuy, buyPrice: buyPrice, namesell: namesell, sellPrice: sellPrice,});
   var json = JSON.stringify(obj);
  
   fs.writeFile(path, json, 'utf8', function (err) {
    if (err) {
        console.log("An error occured while writing JSON Object to File.");
        return console.log(err);
    }
  
    console.log("JSON file has been saved.");
  });
    console.log("DOES NOT exist:", path);

  }






  
};

const writeJsonBuySell = async (jsonname, mindAmountOut, name, price, factoryAdress, routerAddress, swapAmount, currentDate) => {
  const path = jsonname;
  return new Promise((resolve, reject) => {
      if (fs.existsSync(path)) {
        // path exists
        console.log("exists:", path);
        fs.readFile(path, 'utf8', function (err, data){
          if (err){
              console.log(err);
              reject(err);
          } else {
          obj = JSON.parse(data); //now it an object
          obj.table.push({type: jsonname, mindAmountOut: mindAmountOut, name: name, price: price, factoryAdress: factoryAdress, routerAddress: routerAddress, swapAmount: swapAmount, currentDate: currentDate,});
          json = JSON.stringify(obj); //convert it back to json
          fs.writeFile(path, json, 'utf8', function (err) {
            if (err) {
                console.log("An error occured while writing JSON Object to File.");
                reject(err);
            }
          
            console.log("JSON file has been saved.");
            resolve(obj.table);
          });
        }});

      } else {

        var obj = {
          table: []
      };

      obj.table.push({type: jsonname, mindAmountOut: mindAmountOut, name: name, price: price, factoryAdress: factoryAdress, routerAddress: routerAddress, swapAmount: swapAmount, currentDate: currentDate,});
      var json = JSON.stringify(obj);
      
      fs.writeFile(path, json, 'utf8', function (err) {
        if (err) {
            console.log("An error occured while writing JSON Object to File.");
            reject(err);
        }
      
        console.log("JSON file has been saved.");
        resolve(obj.table);
      });
        console.log("DOES NOT exist:", path);
        reject("DOES NOT exist:", path);

      }

    });


};

const overwriteAktivBuys = async (jsonname, anzVerkäufeCounter) => {
  const path = jsonname;
  return new Promise((resolve, reject) => {
      if (fs.existsSync(path)) {
        // path exists
        console.log("exists:", path);
        fs.readFile(path, 'utf8', function (err, data){
          if (err){
              console.log(err);
              reject(err);
          } else {
          obj = JSON.parse(data); //now it an object
          for(let i = 0; i<anzVerkäufeCounter; i++) {
            obj.table.pop();
          }
          json = JSON.stringify(obj); //convert it back to json
          fs.writeFile(path, json, 'utf8', function (err) {
            if (err) {
                console.log("An error occured while writing JSON Object to File.");
                reject(err);
                return console.log(err);
                
            }

          
            console.log("JSON file has been saved.");
            //console.log(obj.table);
            resolve(obj.table);
          });
        }});

      } else {

        
        console.log("file does not exist" + path);
        reject("file does not exist" + path);
      }

  });

};

function readBuys (jsonname) {
  const path = jsonname;

  return new Promise((resolve, reject) => {
    if (fs.existsSync(path)) {
      // path exists
      console.log("exists:", path);
      fs.readFile(path, 'utf8', function (err, data){
        if (err){
            console.log(err);
            reject("");
        } else {
        obj = JSON.parse(data); //now it an object
        //console.log(obj);
        resolve(obj);
      }});
  
    } else {
  
     console.log("No such File :" + jsonname);
     reject("");
  
    }
  });

  

}





module.exports = {
  writeJson,
  writeJsonHighLow,
  writeJsonBuySell,
  overwriteAktivBuys,
  readBuys,

};
